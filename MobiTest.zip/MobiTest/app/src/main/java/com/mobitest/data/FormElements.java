package com.mobitest.data;

/*
 * @Author : Mohammed Ali Mirza
 */

public class FormElements {

    private String id;

    private String caption;

    private String type;

    private boolean isNumber = false;

    private boolean isText = true;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isNumber() {
        return isNumber;
    }

    public void setNumber(boolean number) {
        isNumber = number;
    }

    public boolean isText() {
        return isText;
    }

    public void setText(boolean text) {
        isText = text;
    }

    public enum InputType {
        DATE("date"),
        NUMBER("number");

        private String stringValue;

        InputType(String toString) {
            stringValue = toString;
        }

        @Override
        public String toString() {
            return stringValue;
        }
    }

}
