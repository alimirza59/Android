package com.mobitest.network;

/*
 * @Author : Mohammed Ali Mirza
 */

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    // Base Url for mocky.io
    public static final String BASE_URL = "http://www.mocky.io/v2/";

    private static Retrofit retrofit = null;

    public static String NO_INTERNET_CONNECTION = "No Internet Available";

    public static String ERROR_MESSAGE = "Oops!Something went wrong";

    public static int STATUS_SUCCESS_CODE = 200;


    public static Retrofit getClient() {

        if (retrofit == null) {
            OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(httpClient.build())
                    .build();
        }

        return retrofit;
    }
}
