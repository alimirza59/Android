package com.mobitest.utils;

/*
 * @Author : Mohammed Ali Mirza
 */

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.support.design.widget.Snackbar;

public class CommonUtlities {

    /*
     * Function to check internet Connection
     * @param context : Need Activity context
     */
    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

    /*
     * Function to show Error Messages
     * @param context : Need Activity context
     * @param message : Message to be shown as error
     */
    public static void showError(Activity context, String message){
        Snackbar.make(context.findViewById(android.R.id.content), message, Snackbar.LENGTH_SHORT).show();
    }
}
