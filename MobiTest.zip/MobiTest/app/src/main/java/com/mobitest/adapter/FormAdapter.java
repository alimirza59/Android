package com.mobitest.adapter;

/*
 * @Author : Mohammed Ali Mirza
 */

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.TextView;
import com.mobitest.R;
import com.mobitest.callback.ItemMoveCallback;
import com.mobitest.data.FormElements;
import com.mobitest.databinding.FormItemBinding;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;

public class FormAdapter extends RecyclerView.Adapter<FormAdapter.FormViewHolder> implements ItemMoveCallback.ItemTouchHelperContract {

    private ArrayList<FormElements> formElements;

    private Activity activity;

    private final Calendar myCalendar;

    public FormAdapter(Activity mActivty) {
        this.activity = mActivty;
        this.myCalendar = Calendar.getInstance();
    }

    @NonNull
    @Override
    public FormAdapter.FormViewHolder onCreateViewHolder(@NonNull ViewGroup parent, final int i) {
        LayoutInflater layoutInflater =
                LayoutInflater.from(parent.getContext());
        // Using DataBinding to initialize layout for recycler item
        FormItemBinding formItemBinding = DataBindingUtil.inflate(
                layoutInflater, R.layout.form, parent, false);
        return new FormViewHolder(formItemBinding);

    }

    @Override
    public void onBindViewHolder(@NonNull FormAdapter.FormViewHolder formViewHolder,final int position) {
        formViewHolder.bind(formElements.get(position));
        formViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                if (formElements.get(position).getType().equalsIgnoreCase(FormElements.InputType.DATE.toString())) {
                   showDateDialog(view,position);
                }
            }
        });
    }



    @Override
    public int getItemCount() {
        return formElements.size();
    }

    /*
     * Function to swap form elements
     * @param fromPosition : previous position of the element
     * @param toPosition : new position of the element
     */
    @Override
    public void onRowMoved(int fromPosition, int toPosition) {
        // Swapping arraylist data
        Collections.swap(formElements, fromPosition, toPosition);
        // Notifying item move to the adapter
        notifyItemMoved(fromPosition, toPosition);
        notifyItemChanged(fromPosition);
        notifyItemChanged(toPosition);
    }

    /*
     * Function called when row to be moved is selected
     */
    @Override
    public void onRowSelected(FormAdapter.FormViewHolder myViewHolder) {
        myViewHolder.itemView.setBackgroundColor(Color.LTGRAY);
    }

    /*
     * Function called after row is moved
     */
    @Override
    public void onRowClear(FormAdapter.FormViewHolder myViewHolder) {
        myViewHolder.itemView.setBackgroundColor(Color.WHITE);
    }

    public class FormViewHolder extends RecyclerView.ViewHolder {

        private FormItemBinding formItemBinding;

        public FormViewHolder(FormItemBinding mFormItemBinding) {
            super(mFormItemBinding.getRoot());
            this.formItemBinding = mFormItemBinding;
        }

        public void bind(FormElements elements) {
            formItemBinding.setForm(elements);
        }
    }

    public void setFormElements(ArrayList<FormElements> formElements) {
        this.formElements = formElements;
    }

    /*
     * Date picker Listener when date is changed
     */
    DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        }
    };

    /*
     * Function to show Date Picker
     * @param view : passing the view of recycler item which was clicked
     * @param position : the position of the item which was clicked
     */
    private void showDateDialog(final View view,final int position) {
        DatePickerDialog datePickerDialog=  new DatePickerDialog(activity, date, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                ((TextView) view.findViewById(R.id.txtFormDate)).setText(String.valueOf(formElements.get(position).getCaption()+" : "+ new SimpleDateFormat("dd MMM YYYY").format(myCalendar.getTime())));
            }
        });
        datePickerDialog.show();
    }
}
