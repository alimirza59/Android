package com.mobitest.network.api;

/*
 * @Author : Mohammed Ali Mirza
 */

import com.mobitest.data.Form;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {

    @GET("59f7760a2f0000ab1d55864e")
    Call<Form> getFormData();
}
