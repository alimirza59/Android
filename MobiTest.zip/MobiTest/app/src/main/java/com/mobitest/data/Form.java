package com.mobitest.data;

/*
 * @Author : Mohammed Ali Mirza
 */

import java.util.ArrayList;

public class Form {

    private String userId;

    private String formId;

    private ArrayList<FormElements> form;

    private String lastChangedDate;

    private String lastChangedBy;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public ArrayList<FormElements> getFormElements() {
        return form;
    }

    public void setFormElements(ArrayList<FormElements> formElements) {
        this.form = formElements;
    }

    public String getLastChangedDate() {
        return lastChangedDate;
    }

    public void setLastChangedDate(String lastChangedDate) {
        this.lastChangedDate = lastChangedDate;
    }

    public String getLastChangedBy() {
        return lastChangedBy;
    }

    public void setLastChangedBy(String lastChangedBy) {
        this.lastChangedBy = lastChangedBy;
    }
}
