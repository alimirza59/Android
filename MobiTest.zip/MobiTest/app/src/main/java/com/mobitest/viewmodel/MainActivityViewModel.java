package com.mobitest.viewmodel;

/*
 * @Author : Mohammed Ali Mirza
 */

import android.arch.lifecycle.ViewModel;
import android.databinding.ObservableBoolean;

public class MainActivityViewModel extends ViewModel {
    public ObservableBoolean progress = new ObservableBoolean(false);
}
