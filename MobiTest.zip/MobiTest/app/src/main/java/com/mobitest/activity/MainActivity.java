package com.mobitest.activity;

/*
 * @Author : Mohammed Ali Mirza
 */

import android.arch.lifecycle.ViewModelProviders;
import android.content.DialogInterface;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.helper.ItemTouchHelper;

import com.mobitest.R;
import com.mobitest.callback.ItemMoveCallback;
import com.mobitest.data.FormElements;
import com.mobitest.utils.CommonUtlities;
import com.mobitest.adapter.FormAdapter;
import com.mobitest.data.Form;
import com.mobitest.databinding.MainActivityBinding;
import com.mobitest.network.ApiClient;
import com.mobitest.network.api.ApiInterface;
import com.mobitest.viewmodel.MainActivityViewModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private MainActivityBinding mainActivityBinding;
    private MainActivityViewModel mainActivityViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Using DataBinding to set layout
        mainActivityBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        // Using ViewModelProviders to initialize ViewModel
        mainActivityViewModel = ViewModelProviders.of(this).get(MainActivityViewModel.class);
        // Providing ViewModel instance to the Binding object.
        mainActivityBinding.setViewModel(mainActivityViewModel);
        // Making WebService call to retrieve data from server
        getFormData();
    }

    private void getFormData() {
        if (CommonUtlities.isNetworkAvailable(getBaseContext())) {
            //Showing progress bar
            mainActivityViewModel.progress.set(true);
            ApiInterface service = ApiClient.getClient().create(ApiInterface.class);
            Call<Form> call = service.getFormData();
            call.enqueue(new Callback<Form>() {
                @Override
                public void onResponse(Call<Form> call, Response<Form> response) {
                    //Dismissing progress bar
                    mainActivityViewModel.progress.set(false);
                    // Checking response code
                    if (response.code() == ApiClient.STATUS_SUCCESS_CODE)
                        // Binding response to our views
                        bindViews(response.body());
                    else
                        // Showing Error on unsuccessful WebService call
                        CommonUtlities.showError(MainActivity.this, ApiClient.ERROR_MESSAGE);

                }

                @Override
                public void onFailure(Call<Form> call, Throwable t) {
                    //Dismissing progress bar
                    mainActivityViewModel.progress.set(false);
                    // Showing Error on unsuccessful WebService call
                    CommonUtlities.showError(MainActivity.this, ApiClient.ERROR_MESSAGE);
                }
            });
        } else {
            CommonUtlities.showError(MainActivity.this, ApiClient.NO_INTERNET_CONNECTION);
        }
    }

    private void bindViews(Form form) {
        mainActivityBinding.formId.txtHeader.setText(R.string.formId);
        mainActivityBinding.formId.txtHeaderValue.setText(form.getFormId());

        mainActivityBinding.lastChangedDate.txtHeader.setText(R.string.lastChangedDate);
        mainActivityBinding.lastChangedDate.txtHeaderValue.setText(form.getLastChangedDate());

        mainActivityBinding.lastChangedBy.txtHeader.setText(R.string.lastChangedBy);
        mainActivityBinding.lastChangedBy.txtHeaderValue.setText(form.getLastChangedBy());


        // Setting boolean variables to change input type
        ArrayList<FormElements> formElements = form.getFormElements();

        for (int i = 0; i < formElements.size(); i++) {
            if (formElements.get(i).getType().equalsIgnoreCase(FormElements.InputType.NUMBER.toString())) {
                formElements.get(i).setNumber(true);
            } else if (formElements.get(i).getType().equalsIgnoreCase(FormElements.InputType.DATE.toString())) {
                formElements.get(i).setText(false);
            }
        }

        // Initializing Adapter for dynamic form Elements
        FormAdapter formAdapter = new FormAdapter(this);
        formAdapter.setFormElements(formElements);

        // Initializing drag and drop gesture callback
        ItemTouchHelper.Callback callback =
                new ItemMoveCallback(formAdapter);

        ItemTouchHelper touchHelper = new ItemTouchHelper(callback);

        //Attaching drag and drop to Recyclerview
        touchHelper.attachToRecyclerView(mainActivityBinding.formRecyclerList);

        //Initializing Layout Manager for RecyclerView
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getBaseContext());
        mainActivityBinding.formRecyclerList.setLayoutManager(linearLayoutManager);

        // Setting adapter to Recyclerview
        mainActivityBinding.formRecyclerList.setAdapter(formAdapter);

        // Calling alert function to shown alert
        showAlert();
    }

    /*
     * Show Information Alert about how to Use Drag and drop functionality
     */
    private void showAlert() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle(getResources().getString(R.string.alert_title));
        alertDialogBuilder.setMessage(getResources().getString(R.string.alert_message));
        alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        alertDialogBuilder.show();
    }
}
